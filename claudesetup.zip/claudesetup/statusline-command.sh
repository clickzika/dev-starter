#!/usr/bin/env bash
# Claude Code status line — styled after Git Bash PS1
# Green: user@host  |  Purple: model  |  Yellow: cwd  |  Cyan: git branch

input=$(cat)

# user@host (green)
user_host="$(whoami)@$(hostname -s)"

# Model display name in place of $MSYSTEM (purple)
model=$(echo "$input" | jq -r '.model.display_name')

# Project folder path (yellow)
project_dir=$(echo "$input" | jq -r '.workspace.project_dir')
project="$project_dir"
if [ -n "$HOME" ]; then
  project="${project/#$HOME/\~}"
fi

# Current working directory (yellow), shorten $HOME to ~
cwd_raw=$(echo "$input" | jq -r '.workspace.current_dir')
cwd="$cwd_raw"
if [ -n "$HOME" ]; then
  cwd="${cwd/#$HOME/\~}"
fi

# Git branch (cyan)
git_branch=$(git --no-optional-locks -C "$cwd_raw" symbolic-ref --short HEAD 2>/dev/null)

# Build output — mirrors PS1 layout on a single line without trailing $
printf '\033[32m%s\033[0m ' "$user_host"
printf '\033[35m%s\033[0m ' "$model"
printf '\033[33m%s\033[0m ' "$project"
printf '\033[33m%s\033[0m' "$cwd"
if [ -n "$git_branch" ]; then
  printf ' \033[36m(%s)\033[0m' "$git_branch"
fi
printf '\n'
