# USER.md — Developer Skill Profile

## Purpose

This file tells all agents how to calibrate their output depth.
Place at `~/.claude/USER.md` for global use.
All agents read this file at session start.

**Quick setup:** Run `bash ~/.claude/setup.sh` — it asks 5 questions and fills this file automatically.
**Manual setup:** Edit the levels below directly.

---

## Identity

Name:         Natthaphat
Role:         Developer
Time zone:    Asia/Bangkok
Language:     Thai + English

---

## Overall Level

overall: Expert

---

## Skill Levels

### Programming Languages
| Language    | Level         |
|-------------|---------------|
| JavaScript | Expert       |
| TypeScript | Expert       |
| Python     | Expert       |
| C#         | Expert       |
| Go         | Expert       |
| Java       | Expert       |
| SQL        | Expert       |

### Frameworks & Tools
| Tool                   | Level         |
|------------------------|---------------|
| React / Next.js       | Expert       |
| Angular               | Expert       |
| Vue                   | Expert       |
| Node.js / Express     | Expert       |
| ASP.NET Core          | Expert       |
| Flutter               | Expert       |
| Docker                | Expert       |
| Git / GitHub          | Expert       |
| CI/CD                 | Expert       |
| Cloud (Azure/AWS/GCP) | Expert       |

### Concepts
| Concept          | Level         |
|------------------|---------------|
| REST API design  | Expert       |
| Database design  | Expert       |
| Security (OWASP) | Expert       |
| Testing          | Expert       |
| System design    | Expert       |

---

## Communication Preferences

Response language:    Thai + English
Code comments:        English
Explanation style:    Show full example
Error messages:       Translate to Thai
When I am stuck:      Walk me through step by step

---

## Agent Calibration Rules

When agents read this file, they MUST apply these rules:

| Level        | Agent behavior                                                         |
|--------------|------------------------------------------------------------------------|
| Beginner     | Explain the why. Full working examples. Warnings. Define all jargon.   |
| Intermediate | Brief explanation + code. Skip basics. Highlight non-obvious parts.    |
| Advanced     | Code + trade-offs. No hand-holding. Flag edge cases only.              |
| Expert       | Dense output. Assume full context. Focus on non-trivial only.          |

If USER.md is missing → agent asks once: "What is your experience level with [topic]?"
Then calibrates — never asks again in the same session.
